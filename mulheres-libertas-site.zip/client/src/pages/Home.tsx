import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Heart, Phone, AlertCircle, BookOpen, Users, Mail, ExternalLink } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

/**
 * Design Philosophy: Empowerment & Solidarity
 * - Colors: Purple (#6B21A8) for strength, Gold (#D4AF37) for hope
 * - Typography: Playfair Display for headlines (bold, commanding), Poppins for body (accessible, warm)
 * - Layout: Asymmetric, flowing sections with strategic whitespace
 * - Imagery: Diverse women, powerful stances, uplifting moments
 */

export default function Home() {
  const [showQuickExit, setShowQuickExit] = useState(false);

  const handleQuickExit = () => {
    // Redirect to a neutral page
    window.location.href = "https://www.google.com";
  };

  const handleEmergency = () => {
    toast.error("LIGUE 180 - Denúncia de Violência Contra a Mulher (24h)", {
      description: "Ou 190 para emergências imediatas",
      duration: 5000,
    });
  };

  const handleDenounce = () => {
    toast.info("Canais de Denúncia", {
      description: "Delegacia da Mulher mais próxima ou Ligue 180",
      duration: 4000,
    });
  };

  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* Quick Exit Button - Floating */}
      <button
        onClick={handleQuickExit}
        className="fixed top-4 right-4 z-50 bg-gray-800 text-white px-3 py-2 rounded text-xs font-semibold hover:bg-gray-900 transition"
        title="Sair rapidamente (abre Google)"
      >
        ✕ Sair
      </button>

      {/* Header/Navigation */}
      <header className="sticky top-0 z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src="/manus-storage/logo_voz_ativa_c161524a.png"
              alt="Mulheres Libertas Logo"
              className="h-12 w-12"
            />
            <div>
              <h1 className="text-xl font-bold text-purple-700">Mulheres Libertas</h1>
              <p className="text-xs text-gray-600">Defesa dos Direitos das Mulheres</p>
            </div>
          </div>
          <nav className="hidden md:flex gap-6 text-sm font-medium">
            <a href="#direitos" className="text-gray-700 hover:text-purple-700 transition">
              Direitos
            </a>
            <a href="#ajuda" className="text-gray-700 hover:text-purple-700 transition">
              Ajuda
            </a>
            <a href="#sobre" className="text-gray-700 hover:text-purple-700 transition">
              Sobre
            </a>
            <a href="#contato" className="text-gray-700 hover:text-purple-700 transition">
              Contato
            </a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-screen md:h-[600px] overflow-hidden">
        <img
          src="/manus-storage/hero_voz_ativa_f9f21150.png"
          alt="Mulheres Libertas - Unidas em defesa dos direitos"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="relative h-full flex flex-col items-center justify-center text-center text-white px-4">
          <h1 className="text-5xl md:text-7xl font-bold mb-4 drop-shadow-lg">
            Mulheres Libertas
          </h1>
          <p className="text-xl md:text-2xl mb-8 drop-shadow-md max-w-2xl">
            Juntas somos mais fortes. Luta em defesa dos direitos e da dignidade das mulheres.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              size="lg"
              onClick={handleEmergency}
              className="bg-red-600 hover:bg-red-700 text-white font-bold text-lg px-8"
            >
              <AlertCircle className="mr-2" />
              Ajuda Urgente
            </Button>
            <Button
              size="lg"
              onClick={handleDenounce}
              className="bg-purple-700 hover:bg-purple-800 text-white font-bold text-lg px-8"
            >
              <Phone className="mr-2" />
              Denuncie Agora
            </Button>
          </div>
        </div>
      </section>

      {/* Missão Section */}
      <section id="sobre" className="py-16 md:py-24 bg-gradient-to-r from-purple-50 to-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-purple-900 mb-6">
                Nossa Missão
              </h2>
              <p className="text-lg text-gray-700 mb-4 leading-relaxed">
                <strong>Voz Ativa</strong> é um movimento dedicado à defesa intransigente dos direitos das mulheres. Acreditamos que toda mulher merece viver com dignidade, segurança e igualdade.
              </p>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                Fornecemos informações, apoio e canais para denúncia de violência. Aqui, sua voz importa e será ouvida.
              </p>
              <div className="flex gap-4">
                <Heart className="text-red-500 flex-shrink-0" size={24} />
                <div>
                  <h3 className="font-bold text-gray-900">Solidariedade</h3>
                  <p className="text-sm text-gray-600">Apoiamos umas às outras</p>
                </div>
              </div>
            </div>
            <img
              src="/manus-storage/rights_illustration_2d1d3541.png"
              alt="Mulher estudando direitos"
              className="rounded-lg shadow-lg"
            />
          </div>
        </div>
      </section>

      {/* Direitos Section */}
      <section id="direitos" className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-purple-900 mb-12">
            Conheça Seus Direitos
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Card 1: Lei Maria da Penha */}
            <Card className="p-6 border-l-4 border-purple-700 hover:shadow-lg transition">
              <BookOpen className="text-purple-700 mb-4" size={32} />
              <h3 className="text-xl font-bold text-gray-900 mb-3">Lei Maria da Penha</h3>
              <p className="text-gray-700 mb-4">
                A Lei 11.340/2006 protege mulheres contra violência doméstica e familiar. Ela prevê medidas protetivas urgentes.
              </p>
              <a
                href="https://www.gov.br/cidadania/pt-br/acesso-a-informacao/acoes-e-programas/lei-maria-da-penha"
                target="_blank"
                rel="noopener noreferrer"
                className="text-purple-700 font-semibold hover:text-purple-900 flex items-center gap-2"
              >
                Saiba mais <ExternalLink size={16} />
              </a>
            </Card>

            {/* Card 2: Tipos de Violência */}
            <Card className="p-6 border-l-4 border-yellow-500 hover:shadow-lg transition">
              <AlertCircle className="text-yellow-500 mb-4" size={32} />
              <h3 className="text-xl font-bold text-gray-900 mb-3">Tipos de Violência</h3>
              <p className="text-gray-700 mb-4">
                Física, psicológica, sexual, patrimonial e moral. Todas são crimes. Se você está sofrendo, denuncie.
              </p>
              <a
                href="https://www.gov.br/cidadania/pt-br/acesso-a-informacao/acoes-e-programas/lei-maria-da-penha/tipos-de-violencia"
                target="_blank"
                rel="noopener noreferrer"
                className="text-purple-700 font-semibold hover:text-purple-900 flex items-center gap-2"
              >
                Identificar <ExternalLink size={16} />
              </a>
            </Card>

            {/* Card 3: Seus Direitos */}
            <Card className="p-6 border-l-4 border-pink-500 hover:shadow-lg transition">
              <Heart className="text-pink-500 mb-4" size={32} />
              <h3 className="text-xl font-bold text-gray-900 mb-3">Seus Direitos</h3>
              <p className="text-gray-700 mb-4">
                Direito à segurança, à assistência jurídica, ao acolhimento e à reparação. Você não está sozinha.
              </p>
              <a
                href="https://www.gov.br/cidadania/pt-br/acesso-a-informacao/acoes-e-programas/lei-maria-da-penha/direitos-das-mulheres"
                target="_blank"
                rel="noopener noreferrer"
                className="text-purple-700 font-semibold hover:text-purple-900 flex items-center gap-2"
              >
                Conhecer <ExternalLink size={16} />
              </a>
            </Card>
          </div>
        </div>
      </section>

      {/* Ajuda Section */}
      <section id="ajuda" className="py-16 md:py-24 bg-gradient-to-r from-purple-900 to-purple-800 text-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-12">
            Canais de Ajuda
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {/* Emergência */}
            <div className="bg-white/10 backdrop-blur p-8 rounded-lg border border-white/20">
              <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <AlertCircle size={28} className="text-red-400" />
                Emergência
              </h3>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-200">Violência Contra a Mulher</p>
                  <p className="text-3xl font-bold text-yellow-300">180</p>
                </div>
                <div>
                  <p className="text-sm text-gray-200">Emergência Geral</p>
                  <p className="text-3xl font-bold text-red-400">190</p>
                </div>
                <p className="text-sm text-gray-300 pt-4">
                  Disponível 24 horas. Gratuito. Sigilo garantido.
                </p>
              </div>
            </div>

            {/* Denúncia */}
            <div className="bg-white/10 backdrop-blur p-8 rounded-lg border border-white/20">
              <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Phone size={28} className="text-green-400" />
                Denuncie
              </h3>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-200">Delegacia da Mulher</p>
                  <p className="text-lg font-semibold">Procure a mais próxima</p>
                </div>
                <div>
                  <p className="text-sm text-gray-200">Boletim de Ocorrência Online</p>
                  <p className="text-lg font-semibold">Em alguns estados</p>
                </div>
                <p className="text-sm text-gray-300 pt-4">
                  Você pode denunciar anonimamente. Seus direitos serão protegidos.
                </p>
              </div>
            </div>

            {/* Acolhimento */}
            <div className="bg-white/10 backdrop-blur p-8 rounded-lg border border-white/20">
              <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Users size={28} className="text-blue-400" />
                Acolhimento
              </h3>
              <div className="space-y-3">
                <p className="text-gray-200">
                  Centros de acolhimento, casas-abrigo e apoio psicológico disponíveis em sua região.
                </p>
                <Button
                  onClick={() => toast.info("Consulte a prefeitura de sua cidade")}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold mt-4"
                >
                  Encontrar Centro
                </Button>
              </div>
            </div>

            {/* Apoio Jurídico */}
            <div className="bg-white/10 backdrop-blur p-8 rounded-lg border border-white/20">
              <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <BookOpen size={28} className="text-purple-300" />
                Apoio Jurídico
              </h3>
              <div className="space-y-3">
                <p className="text-gray-200">
                  Defensorias públicas e organizações oferecem assistência jurídica gratuita.
                </p>
                <Button
                  onClick={() => toast.info("Procure a Defensoria Pública de sua região")}
                  className="w-full bg-purple-500 hover:bg-purple-600 text-white font-semibold mt-4"
                >
                  Saber Mais
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Estatísticas Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-purple-900 mb-12">
            A Realidade das Mulheres no Brasil
          </h2>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <p className="text-5xl font-bold text-red-600 mb-2">5</p>
              <p className="text-gray-700">
                Espancamentos a cada 2 minutos
              </p>
            </div>
            <div className="text-center">
              <p className="text-5xl font-bold text-red-600 mb-2">1</p>
              <p className="text-gray-700">
                Estupro a cada 11 minutos
              </p>
            </div>
            <div className="text-center">
              <p className="text-5xl font-bold text-red-600 mb-2">1</p>
              <p className="text-gray-700">
                Feminicídio a cada 90 minutos
              </p>
            </div>
            <div className="text-center">
              <p className="text-5xl font-bold text-purple-700 mb-2">∞</p>
              <p className="text-gray-700">
                Razões para lutar
              </p>
            </div>
          </div>
          <p className="text-center text-gray-600 mt-12 text-sm">
            *Dados aproximados baseados em estatísticas oficiais. Estes números representam apenas os casos denunciados.
          </p>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-purple-700 to-purple-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Você Não Está Sozinha
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Se você está sofrendo violência, procure ajuda agora. Existem pessoas e organizações prontas para apoiá-la.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://www.gov.br/cidadania/pt-br/acesso-a-informacao/acoes-e-programas/ligue-180"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center bg-red-600 hover:bg-red-700 text-white font-bold text-lg px-8 py-3 rounded-lg transition"
            >
              <AlertCircle className="mr-2" />
              Ligar 180
            </a>
            <a
              href="https://www.gov.br/cidadania/pt-br/acesso-a-informacao/acoes-e-programas/lei-maria-da-penha/denuncie"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-bold text-lg px-8 py-3 rounded-lg transition"
            >
              Denuncie
            </a>
          </div>
        </div>
      </section>
      {/* Contact Section */}
      <section id="contato" className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-purple-900 mb-12">
            Entre em Contato
          </h2>
          <div className="max-w-2xl mx-auto">
            <Card className="p-8">
              <form className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Nome
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-700"
                    placeholder="Seu nome"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-700"
                    placeholder="seu@email.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Mensagem
                  </label>
                  <textarea
                    rows={5}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-700"
                    placeholder="Sua mensagem..."
                  ></textarea>
                </div>
                <Button
                  type="submit"
                  className="w-full bg-purple-700 hover:bg-purple-800 text-white font-bold py-3"
                  onClick={(e) => {
                    e.preventDefault();
                    toast.success("Mensagem enviada com sucesso!");
                  }}
                >
                  <Mail className="mr-2" size={20} />
                  Enviar Mensagem
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="text-white font-bold mb-4">Mulheres Libertas</h3>
              <p className="text-sm">
                Defesa e direitos das mulheres. Juntas somos mais fortes.
              </p>
            </div>
            <div>
              <h3 className="text-white font-bold mb-4">Links Rápidos</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="#direitos" className="hover:text-white transition">
                    Direitos
                  </a>
                </li>
                <li>
                  <a href="#ajuda" className="hover:text-white transition">
                    Ajuda
                  </a>
                </li>
                <li>
                  <a href="#contato" className="hover:text-white transition">
                    Contato
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-bold mb-4">Emergência</h3>
              <p className="text-sm font-semibold text-red-400">Ligue 180</p>
              <p className="text-xs">Violência contra a mulher (24h)</p>
            </div>
          </div>
          <div className="border-t border-gray-700 pt-8 text-center text-sm">
            <p>&copy; 2026 Mulheres Libertas. Todos os direitos reservados. | Feito com ❤️ pela defesa dos direitos das mulheres.</p>
            <p className="mt-4 text-xs text-gray-400">
              Desenvolvido por Carlos Daniel De Souza Santana
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
